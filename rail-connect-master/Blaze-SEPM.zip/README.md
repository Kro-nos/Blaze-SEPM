# rail_connect
An Indian Railway Information Website built using the Indian Railways Api Having functionalities - Live Train Status , Pnr status,
seeing cancelled trains,checking routes of trains and many other options available by API of Indian Railway.

As well has a user/admin system (login/signup) to provide a demo reservation of seats.

1. To clone the repo Download Zip or just git clone [https:link of the repo]
2. Install Lamp, Xamp, Wamp depending upon the OS you are using and access index.php on localhost, Your site is up!

Built for completion of Software Engineering project -Sem 4th.
